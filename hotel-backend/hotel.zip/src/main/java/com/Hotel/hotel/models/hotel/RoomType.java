package com.Hotel.hotel.models.hotel;

public enum RoomType {
    SINGLE,
    DOUBLE,
    SUITE,
    MATRIMONIAL
}
