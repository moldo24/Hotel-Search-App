This is the HOTEL Project for the Siemens Internship


You can log in as admin using
name: admin@admin.com
password: password

The Log in and Spring Security we're made mostly for having more than one user to test different ways to make reservations
I used Thymeleaf and not Angular or anything else for the frontend because of the email size, Angular would've taken 100MB in a .zip
~~~~Do not read from here if not interested~~~~
I also put mostly every call in the HotelController mostly out of rush, and I would love to add a bit more to this project but I don't have that much time
The way I made most of this stuff is using things learned from my university projects i hope they are ok.
